package week7.assignments.day2.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;
import week7.assignments.day1.readExcel.ReadExcel;

public class BaseClass {

	// public ChromeDriver driver;
	private static final ThreadLocal<WebDriver> tldriver = new ThreadLocal<WebDriver>();

	public void setDriver(WebDriver driver) {
		tldriver.set(driver);
	}

	public WebDriver getDriver() {
		return tldriver.get();
	}

	public static Properties prop;
	public static Properties prop1;

	public String fileName;
	public String sheetName;

	@BeforeMethod
	public void preCondition() throws IOException {

		prop = new Properties();
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/AppProperties.properties"));
		prop.load(fis);

		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		setDriver(new ChromeDriver(options));
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		getDriver().get(prop.getProperty("url"));
		getDriver().manage().window().maximize();

		String lang = prop.getProperty("lang");

		prop1 = new Properties();
		FileInputStream fis2 = new FileInputStream(new File("./src/main/resources/" + lang + ".properties"));
		prop1.load(fis2);
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	@DataProvider(parallel = true)
	public String[][] fetchData() throws IOException {
		return ReadExcel.readExcelData(fileName, sheetName);
	}
}

package week7.assignments.day2.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.assignments.day2.base.BaseClass;
import week7.assignments.day2.page.FindLead;
import week7.assignments.day2.page.MainPage;

public class FindLeadTestcase extends BaseClass {

	@BeforeTest
	public void setFileNames() {
		fileName = "FindLead";
		sheetName = "FindLead";
	}

	@Test(dataProvider = "fetchData")
	public void findLeadTest(String emailSearch) throws InterruptedException {
		MainPage mp = new MainPage();
		mp.enterUserName(prop1.getProperty("username")).enterPassword(prop.getProperty("password")).clickLogin()
				.clickCRMSFA().clickLeads().findLead().clickEmail().enterEmailSearch(emailSearch).clickFindLead();

		FindLead fl = new FindLead();
		String leadName = fl.captureFirstLead();
		fl.clickFirstLead().clickDuplicateButton().findLeadSubmit().leadNameValidation(leadName);
	}
}

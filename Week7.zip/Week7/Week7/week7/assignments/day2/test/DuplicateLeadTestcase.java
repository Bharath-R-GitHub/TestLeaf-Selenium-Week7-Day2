package week7.assignments.day2.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.assignments.day2.base.BaseClass;
import week7.assignments.day2.page.MainPage;

public class DuplicateLeadTestcase extends BaseClass {

	@BeforeTest
	public void setFileNames() {
		fileName = "DuplicateLead";
		sheetName = "DuplicateLead";
	}

	@Test(dataProvider = "fetchData")
	public void duplicateLeadTest(String cName, String fName, String lName, String localFName, String dept, String desc,
			String eMail, String state, String newCmpName, String newFName) {
		MainPage mp = new MainPage();
		mp.enterUserName(prop1.getProperty("username")).enterPassword(prop.getProperty("password")).clickLogin()
				.clickCRMSFA().clickLeads().clickCreateLead().enterCompanyName(cName).enterFirstName(fName)
				.enterLastName(lName).enterFirstNameLocal(localFName).enterDeptName(dept).enterDesc(desc)
				.enterMail(eMail).enterState(state).duplicateLead().clickDuplicateButton()
				.enterNewCompanyName(newCmpName).enterNewFirstName(newFName).clickCreateDuplicate()
				.leadValidate(newFName);
	}
}

package week7.assignments.day2.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import week7.assignments.day2.base.BaseClass;
import week7.assignments.day2.page.FindLead;
import week7.assignments.day2.page.MainPage;

public class DeleteLeadTestcase extends BaseClass {

	@BeforeTest
	public void setFileNames() {
		fileName = "DeleteLead";
		sheetName = "DeleteLead";
	}

	@Test(dataProvider = "fetchData")
	public void deleteLeadTest(String phnNumSearch) throws InterruptedException {
		MainPage mp = new MainPage();
		mp.enterUserName(prop1.getProperty("username")).enterPassword(prop.getProperty("password")).clickLogin()
				.clickCRMSFA().clickLeads().findLead().clickPhone().enterPhoneNumber(phnNumSearch).clickFindLead();

		FindLead fl = new FindLead();
		String leadID = fl.captureFirstLeadID();
		fl.clickFirstLead().clickDeleteButton().leads().findLead().enterCaptureLeadId(leadID).clickFindLead()
				.validation().leadIDValidation();
	}
}
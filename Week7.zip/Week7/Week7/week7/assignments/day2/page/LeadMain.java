package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class LeadMain extends BaseClass {

//	public LeadMain(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public CreateLead clickCreateLead() {
		getDriver().findElement(By.linkText(prop1.getProperty("create_lead_link"))).click();
		return new CreateLead();
		//return new CreateLead(driver);
	}
	
	public FindLead findLead() {
		getDriver().findElement(By.linkText(prop1.getProperty("find_lead_link"))).click();
		return new FindLead();
		//return new FindLead(driver);
	}
}

package week7.assignments.day2.page;

import org.openqa.selenium.By;
import org.testng.Assert;

import week7.assignments.day2.base.BaseClass;

public class ViewLead extends BaseClass{
	
//	public ViewLead(ChromeDriver driver) {
//		this.driver = driver;
//	}
	
	public void leadValidate(String expected) {
		String actual = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		Assert.assertEquals(actual, expected);
	}
}

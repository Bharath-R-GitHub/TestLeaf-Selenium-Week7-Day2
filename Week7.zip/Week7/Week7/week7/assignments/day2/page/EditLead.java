package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class EditLead extends BaseClass{

//	public EditLead(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	public EditLeadDetails clickEditButton() {
		getDriver().findElement(By.linkText(prop1.getProperty("edit_lead_link"))).click();
		return new EditLeadDetails();
		//return new EditLeadDetails(driver);
	}
}

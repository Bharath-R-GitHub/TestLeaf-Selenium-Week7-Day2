package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class HomePage extends BaseClass {

//	public HomePage(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public LeadMain clickLeads() {
		getDriver().findElement(By.linkText(prop1.getProperty("leads_link"))).click();
		return new LeadMain();
		//return new LeadMain(driver);
	}

}

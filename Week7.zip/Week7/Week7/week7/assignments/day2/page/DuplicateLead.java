package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class DuplicateLead extends BaseClass {

//	public DuplicateLead(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public DuplicateLeadDetails clickDuplicateButton() {
		getDriver().findElement(By.linkText(prop1.getProperty("duplicte_lead_link"))).click();
		return new DuplicateLeadDetails();
		//return new DuplicateLeadDetails(driver);
	}

	public DeleteLead clickDeleteButton() {
		getDriver().findElement(By.xpath("//a[text()='"+prop1.getProperty("delete_lead_link")+"']")).click();
		return new DeleteLead();
		//return new DeleteLead(driver);
	}
}

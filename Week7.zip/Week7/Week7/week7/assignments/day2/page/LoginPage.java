package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class LoginPage extends BaseClass {

//	public LoginPage(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public HomePage clickCRMSFA() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
		//return new HomePage(driver);
	}
}

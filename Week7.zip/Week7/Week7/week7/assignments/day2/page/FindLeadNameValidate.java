package week7.assignments.day2.page;

import org.openqa.selenium.By;
import org.testng.Assert;

import week7.assignments.day2.base.BaseClass;

public class FindLeadNameValidate extends BaseClass {

//	public FindLeadNameValidate(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public void leadNameValidation(String expected) {
		String dupFName = getDriver().findElement(By.xpath("//span[contains(@id,'firstName')]")).getText();
		String dupLName = getDriver().findElement(By.xpath("//span[contains(@id,'lastName')]")).getText();
		String actual = dupFName + " " + dupLName;
		Assert.assertEquals(actual, expected);
	}
}

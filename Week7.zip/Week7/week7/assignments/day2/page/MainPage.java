package week7.assignments.day2.page;

import org.openqa.selenium.By;
import week7.assignments.day2.base.BaseClass;

public class MainPage extends BaseClass {

//	public MainPage(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public MainPage enterUserName(String uName) {
		getDriver().findElement(By.id("username")).sendKeys(uName);
		return this;
	}

	public MainPage enterPassword(String pWord) {
		getDriver().findElement(By.id("password")).sendKeys(pWord);
		return this;
	}

	public LoginPage clickLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
		//return new LoginPage(driver);
	}

}

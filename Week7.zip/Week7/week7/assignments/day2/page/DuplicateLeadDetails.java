package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class DuplicateLeadDetails extends BaseClass {

//	public DuplicateLeadDetails(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public DuplicateLeadDetails enterNewCompanyName(String nCmpName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).clear();
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(nCmpName);
		return this;
	}

	public DuplicateLeadDetails enterNewFirstName(String nFName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).clear();
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(nFName);
		return this;
	}

	public ViewLead clickCreateDuplicate() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewLead();
		//return new ViewLead(driver);
	}
	
	public FindLeadNameValidate findLeadSubmit() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new FindLeadNameValidate();
		//return new FindLeadNameValidate(driver);
	}

}

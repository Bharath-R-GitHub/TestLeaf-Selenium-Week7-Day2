package week7.assignments.day2.page;

import org.testng.Assert;

import week7.assignments.day2.base.BaseClass;

public class DeleteLeadValidate extends BaseClass {

	public boolean actual;

	public DeleteLeadValidate(boolean actual) {
		this.actual = actual;
	}

	public void leadIDValidation() {
		Assert.assertTrue(actual);
	}
}

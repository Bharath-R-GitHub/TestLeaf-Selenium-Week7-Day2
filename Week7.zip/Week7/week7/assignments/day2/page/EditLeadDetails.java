package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class EditLeadDetails extends BaseClass{
	
//	public EditLeadDetails(ChromeDriver driver) {
//		this.driver = driver;
//	}
	
	public EditLeadDetails enterImpNote(String impNote) {
		getDriver().findElement(By.id("updateLeadForm_description")).clear();
		getDriver().findElement(By.id("updateLeadForm_importantNote")).sendKeys(impNote);
		return this;
	}
	
	public ViewLead clickUpdate() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewLead();
		//return new ViewLead(driver);
	}
}

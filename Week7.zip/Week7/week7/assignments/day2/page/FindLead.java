package week7.assignments.day2.page;

import org.openqa.selenium.By;

import week7.assignments.day2.base.BaseClass;

public class FindLead extends BaseClass {

//	public FindLead(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public FindLead clickEmail() {
		getDriver().findElement(By.linkText("Email")).click();
		return this;
	}

	public FindLead enterEmailSearch(String emailSearch) {
		getDriver().findElement(By.xpath("//label[text()='Email Address:']/following-sibling::div/input"))
				.sendKeys(emailSearch);
		return this;
	}

	public FindLead clickPhone() {
		getDriver().findElement(By.xpath("//span[text()='Phone']")).click();
		return this;
	}

	public FindLead enterPhoneNumber(String phnNumSearch) {
		getDriver().findElement(By.name("phoneNumber")).sendKeys(phnNumSearch);
		return this;
	}

	public FindLead clickFindLead() throws InterruptedException {
		getDriver().findElement(By.xpath("//button[text()='"+prop1.getProperty("find_lead_link")+"']")).click();
		Thread.sleep(2000);
		return this;
	}

	public String captureFirstLead() {
		String fName = getDriver().findElement(By.xpath("//div[contains(@class,'x-grid3-col-firstName')]/a")).getText();
		String lName = getDriver().findElement(By.xpath("//div[contains(@class,'x-grid3-col-lastName')]/a")).getText();
		String name = fName + " " + lName;
		return name;
	}

	public String captureFirstLeadID() {
		String leadID = getDriver().findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a[1]")).getText();
		return leadID;
	}

	public FindLead enterCaptureLeadId(String capLeadID) {
		getDriver().findElement(By.xpath("//div[@class='x-form-element']/input[@name='id']")).sendKeys(capLeadID);
		return this;
	}

	public DuplicateLead clickFirstLead() {
		getDriver().findElement(By.xpath("//div[contains(@class,'x-grid3-col-partyId')]/a")).click();
		return new DuplicateLead();
		//return new DuplicateLead(driver);
	}

	public DeleteLeadValidate validation() {
		boolean actual = false;
		String verify = getDriver().findElement(By.xpath("//div[@class='x-paging-info']")).getText();
		if (verify.equals("No records to display")) {
			actual = true;
		}
		return new DeleteLeadValidate(actual);
		//return new DeleteLeadValidate(driver, actual);
	}
}

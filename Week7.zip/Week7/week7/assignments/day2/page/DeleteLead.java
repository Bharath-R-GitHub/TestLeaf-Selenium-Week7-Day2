package week7.assignments.day2.page;

import week7.assignments.day2.base.BaseClass;

public class DeleteLead extends BaseClass{
	
//	public DeleteLead(ChromeDriver driver) {
//		this.driver = driver;
//	}
	
	public LeadMain leads() {
		return new LeadMain();
		//return new LeadMain(driver);
	}
}

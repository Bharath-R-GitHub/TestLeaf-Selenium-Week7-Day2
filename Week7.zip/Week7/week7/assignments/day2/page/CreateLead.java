package week7.assignments.day2.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import week7.assignments.day2.base.BaseClass;

public class CreateLead extends BaseClass {

//	public CreateLead(ChromeDriver driver) {
//		this.driver = driver;
//	}

	public CreateLead enterCompanyName(String cName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;
	}

	public CreateLead enterFirstName(String fName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
	}

	public CreateLead enterLastName(String lName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
	}

	public CreateLead enterFirstNameLocal(String fNameLocal) {
		getDriver().findElement(By.id("createLeadForm_firstNameLocal")).sendKeys(fNameLocal);
		return this;
	}

	public CreateLead enterDeptName(String deptName) {
		getDriver().findElement(By.id("createLeadForm_departmentName")).sendKeys(deptName);
		return this;
	}

	public CreateLead enterDesc(String desc) {
		getDriver().findElement(By.id("createLeadForm_description")).sendKeys(desc);
		return this;
	}

	public CreateLead enterMail(String email) {
		getDriver().findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
		return this;
	}
	
	public CreateLead enterPhoneNumber(String phNum) {
		getDriver().findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phNum);
		return this;
	}

	public CreateLead enterState(String state) {
		WebElement ddElement = getDriver().findElement(By.id("createLeadForm_generalStateProvinceGeoId"));
		Select dd = new Select(ddElement);
		dd.selectByVisibleText(state);
		return this;
	}
	
	public EditLead editLead() {
		getDriver().findElement(By.name("submitButton")).click();
		return new EditLead();
		//return new EditLead(driver);
	}
	
	public DuplicateLead duplicateLead() {
		getDriver().findElement(By.name("submitButton")).click();
		return new DuplicateLead();
		//return new DuplicateLead(driver);
	}

	public ViewLead createLeadValidate() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLead();
		//return new ViewLead(driver);
	}
}

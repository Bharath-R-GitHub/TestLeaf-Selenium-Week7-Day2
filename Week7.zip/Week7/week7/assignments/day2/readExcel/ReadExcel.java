package week7.assignments.day2.readExcel;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static String[][] readExcelData(String fileName, String sheetName) throws IOException {
		XSSFWorkbook wb = new XSSFWorkbook("./week_7_Test_Data/" + fileName + ".xlsx");
		XSSFSheet ws = wb.getSheet(sheetName);
		int lastRowNum = ws.getLastRowNum();
		int lastCellNum = ws.getRow(0).getLastCellNum();

		String[][] excelData = new String[lastRowNum][lastCellNum];
		for (int i = 1; i <= lastRowNum; i++) {
			for (int j = 0; j < lastCellNum; j++) {
				excelData[i - 1][j] = ws.getRow(i).getCell(j).getStringCellValue();
			}
		}

		wb.close();
		return excelData;
	}
}
